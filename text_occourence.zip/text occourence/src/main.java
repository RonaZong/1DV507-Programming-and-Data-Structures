import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class main {

	ArrayList<word> words = new ArrayList<word>();

	public static void main(String[] args) throws Exception {

		main m = new main();
		URL url = main.class.getClassLoader().getResource("lovecraft2.txt");
		Scanner sc = new Scanner(url.openStream());

		System.out.println("Scanning...");

		int i = 0;
		while (sc.hasNextLine()) {
			m.scanLine(sc.nextLine());
			i++;
			System.out.println(i);
		}

		Collections.sort(m.words, (p1, p2) -> p2.getOccource() - p1.getOccource());

		System.out.println("Most occouring word: " + m.words.get(0).name + "-" + m.words.get(0).occource);
		System.out.println("Second most occouring word: " + m.words.get(1).name + "-" + m.words.get(1).occource);
		System.out.println("Third Most occouring word: " + m.words.get(2).name + "-" + m.words.get(2).occource);
		System.out.println("done");
	}

	public void scanLine(String line) {
		String[] words = line.split("\\s+");
		for (String word : words) {
			if (containsWord(word)) {
				incramentWord(word);
			} else {
				addWord(word);
			}
		}
	}

	public boolean containsWord(String word) {
		return words.stream().filter(o -> o.getName().equals(word)).findFirst().isPresent();
	}

	public void addWord(String word) {
		words.add(new word(word));
	}

	public void incramentWord(String word) {
		words.stream().filter(o -> o.getName().equals(word)).findFirst().get().incrament();
	}

}
