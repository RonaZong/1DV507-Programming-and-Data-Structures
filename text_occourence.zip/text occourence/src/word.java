
public class word {

	public String name;
	public int occource;
	
	public word(String name) {
		this.name = name;
		this.occource = 1;
	}
	
	public void incrament() {
		this.occource++;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getOccource() {
		return occource;
	}

	public void setOccource(int occource) {
		this.occource = occource;
	}
	
	
	
	
}
