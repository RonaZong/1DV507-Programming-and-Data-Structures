package count_words;

import java.util.Arrays;
import java.util.Iterator;

public class TreeWordSet implements WordSet {
    private BST root = null;
    private int size = 0;

   public void add (Word w) {
        if (root == null) {
            root = new BST(w);
            size++;
        }
        else root.add(w); size++;
    }

    private class BST {
        Word w;
        BST left = null;
        BST right = null;
        BST(Word w) {this.w = w;}

        public void add(Word word) {
            if (word.compareTo(w)<0) {
                if (left == null) {
                    left = new BST(word);
                } else { left.add(word);}}
                else if (word.compareTo(w)>0) {
                    if (right == null) {
                        right = new BST(word);
                }
                    else{right.add(word);}
            }
        }

        public boolean contains(Word word) {
            if (word.compareTo(w)<0) {
                if (left == null) {
                    return false;
                } else { left.contains(w);}}
            else if (word.compareTo(w)>0) {
                if (right == null) {
                    return false;
                }
                else{right.contains(w);}
            }
            return true;
        }
        public String toString() {
            return w.toString();
        }

    }

    public String toString() {
       return root.toString();
    }


    @Override
    public boolean contains(Word word) {
       return root.contains(word);
    }

    @Override
    public int size() {
        return size/2;
    }

    @Override
    public Iterator<Word> iterator() {
        return new itr(root);
    }

    private class itr implements Iterator<Word> {
    Word[] arr;
    int counter;
    int index;

    public itr(BST root) {
        this.arr = new Word[size];
        this.index = 0;
        this.sort(root);
        this.counter = 0;
        System.out.println(Arrays.toString(arr));
    }

    private void sort(BST root) {
        if (root == null) {
            return;
        }
        this.sort(root.left);
        arr[counter] = root.w;
        counter++;
        this.sort(root.right);

    }

        @Override
        public boolean hasNext() {
            if (arr[index] != null) {
                return true;
            }
            else return false;
        }

        @Override
        public Word next() {
        Word temp = null;
        if (hasNext()) {
            index++;
            temp = arr[index-1];
        }
        return temp;
    }
    }
}
