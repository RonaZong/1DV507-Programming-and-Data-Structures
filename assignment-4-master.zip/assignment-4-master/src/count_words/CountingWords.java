package count_words;

import java.io.*;
import java.lang.reflect.Array;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CountingWords {





    public static void main(String[] args) throws IOException {
        ArrayList<String> clear = new ArrayList<>();
       Path path = Paths.get(System.getProperty("user.dir") + "\\src\\count_words\\HistoryOfProgramming.txt");
        File f = new File(String.valueOf(path));
        Scanner s = new Scanner(f);


       while (s.hasNext()) {
           //nextall for print next for cataloging
          String temp = s.nextLine();
          temp = temp.replaceAll("([^a-zA-Z\n ])","");
          clear.add(temp);
          System.out.println(temp);
          }

        FileWriter fw = new FileWriter(new File("text.txt"));
        for (String s2: clear) {
            fw.write(s2 + "\n" );
            fw.flush();
            System.out.println(s2);
        }
        System.out.println(clear.size());
    }


}
