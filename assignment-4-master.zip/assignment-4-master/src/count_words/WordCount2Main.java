package count_words;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class WordCount2Main {
    public static void main(String[] args) throws IOException {
        HashWordSet clear = new HashWordSet();
        TreeWordSet clear2 = new TreeWordSet();
        Path path = Paths.get(System.getProperty("user.dir") + "\\src\\HistoryOfProgramming.txt");
        File f = new File(String.valueOf(path));
        Scanner s = new Scanner(f);

        while (s.hasNext()) {
            //nextall for print next for cataloging
            String temp = s.next();
            temp = temp.replaceAll("([^a-zA-Z\n ])", "");
            Word w = new Word(temp);
            clear.add(w);
            clear2.add(w);

        }
        Word test = new Word("def");
        System.out.println(clear.contains(test));
        System.out.println(clear.getSize());
        System.out.println(clear2.contains(test));
        System.out.println(clear2.size());
        clear2.iterator().hasNext();

      }
}
