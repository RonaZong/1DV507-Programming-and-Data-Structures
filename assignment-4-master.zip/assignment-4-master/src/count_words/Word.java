package count_words;

import java.util.Comparator;

public class Word implements Comparable<Word> {
    private String word;

    public Word(String str) { this.word = str; }

    public String toString() { return word; }

    /* Override Object methods */
    public int hashCode() {return word.toLowerCase().hashCode(); }
    public boolean equals(Object other) {
        if( word.toLowerCase().hashCode()==other.toString().toLowerCase().hashCode()){
        return true;
    } else
    return false;}

    /* Implement Comparable */
    public int compareTo(Word w) { Comparator<String> c = Comparator.comparing(String::toString);
    return c.compare(word, w.word);}
}
