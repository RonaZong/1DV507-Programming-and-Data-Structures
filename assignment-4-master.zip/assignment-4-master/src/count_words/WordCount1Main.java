package count_words;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.TreeSet;

public class WordCount1Main {
    public static void main(String[] args) throws IOException {
        ArrayList<Word> clear = new ArrayList<>();
        Path path = Paths.get(System.getProperty("user.dir") + "\\src\\HistoryOfProgramming.txt");
        File f = new File(String.valueOf(path));
        Scanner s = new Scanner(f);
        HashSet h = new HashSet();
        TreeSet t = new TreeSet();

        while (s.hasNext()) {
            //nextall for print next for cataloging
            String temp = s.next();
            temp = temp.replaceAll("([^a-zA-Z\n ])", "");
            Word w = new Word(temp);
            clear.add(w);

            h.add(w);
            t.add(w);
        }

        System.out.println(t.size());
        System.out.println(h.size());
    }

}
