package count_words;

import java.util.Iterator;

public class HashWordSet implements WordSet {

    private int size;
    public Node[] buckets = new Node[8];

    /*
    . In the case of hashing, a rehash shall be performed when the number of inserted elements equals the number of buckets.
     */

    private class Node {
        Word word;
        Node next = null;

        public Node(Word word) {
            this.word = word;
        }
        public String toString() {
            return word.toString();
        }
    }

    @Override
    public void add(Word word) {
    int pos = getHash(word);
    Node n = buckets[pos];
        while (n != null) {
            if (n.word.equals(word)) {
                return;
            }
            else
                n = n.next;
        }
        n = new Node(word);
        n.next = buckets[pos];
        buckets[pos] = n;
        size++;
        if (size == buckets.length) {
            rehash();
        }


    }

    private void rehash() {
        Node[] temp = buckets;
        buckets = new Node[temp.length*2];
        size = 0;
        for (Node n:
             temp) { if (n == null) continue;
             while (n != null) {
                 add(n.word);
                 n = n.next;
             }

        }


    }

    @Override
    public boolean contains(Word word) {
        int pos = getHash(word);
        Node n = buckets[pos];
        while (n!=null) {
            if (n.word.equals(word)) {
                return true;
            }
            else n = n.next;
        }
        return false;
    }

    @Override
    public int size() {
        return this.size;
    }

   @Override
    public Iterator<Word> iterator() {
       return new itr();
   }

       class itr implements Iterator {
           Node curr;
           int index;
           itr() {
               for (int i = 0; i < buckets.length; i++) {
                   if (buckets[i] != null) {
                       curr = buckets[i];
                       index = i;
                       break;
                   }
               }
           }

           @Override
           public boolean hasNext() {
               return curr != null;
           }

           @Override
           public Word next() {
               Word temp = null;
               if (curr != null) {
                   temp = curr.word;
               }
               if (curr != null && curr.next != null) {
                   curr = curr.next;
               } else {
                   curr = null;
                   for (int i = 0; i < buckets.length; i++) {
                       if (buckets[i] != null) {
                           curr = buckets[i];
                           index = i;
                           break;
                       }
                   }
               }
               return temp;
           }
       }



    private int getHash(Word word) {
        return ((Math.abs(word.hashCode()))%buckets.length);
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Node[] getBuckets() {
        return buckets;
    }

    public void setBuckets(Node[] buckets) {
        this.buckets = buckets;
    }
}
