package time;

import java.util.Random;

public class StringTiming {
    private static long counter;
    private static String a;
    private static StringBuilder s = new StringBuilder();
    private static long[] timeValues = new long[10];

    public static void main(String[] args) {
    for (int i = 0; i<10; i++) {
        long start = System.currentTimeMillis();
        long duration = 0;
        long end = 0;
        counter = 0;

        while (duration < 1000) {
            appendShort();
            end = System.currentTimeMillis();
            duration = (end - start);
        }

        timeValues[i] = counter;
    }
        System.out.println("short average");
       calculateAverage(timeValues);

        for (int i = 0; i<10; i++) {
            long start = System.currentTimeMillis();
            long duration = 0;
            long end = 0;
            counter = 0;

            while (duration < 1000) {
                appendLong();
                end = System.currentTimeMillis();
                duration = (end - start);
            }

            timeValues[i] = counter;
        }
        System.out.println("long average");
        calculateAverage(timeValues);

    }

    public static void concShort() {
            a = a+generateWord(1);
            counter++;
    }

    public static void concLong() {
        a = a + generateWord(80);
        counter++;

    }
    public static void appendShort() {
        s.append(generateWord(1));
        counter++;
    }

    public static void appendLong() {
        s.append(generateWord(80));
        counter++;

    }

    public static void calculateAverage(long[] time) {
        long total = 0;
        for (int i=0; i<time.length; i++) {
            total = time[i] + total;
        }
        System.out.println(total/time.length);
    }


    public static String generateWord(int n) {
        int lower = 97;
        int upperbound = 122;
        Random r = new Random();
        StringBuffer string = new StringBuffer(n);
        for (int i =0; i<n; i++) {
            int next = lower+(int)r.nextFloat()*upperbound-lower+1; // https://www.geeksforgeeks.org/generate-random-string-of-given-size-in-java/
            string.append((char)next);
        }
        return string.toString();
    }


}
