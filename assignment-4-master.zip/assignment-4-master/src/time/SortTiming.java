package time;

import java.util.Arrays;
import java.util.Random;

public class SortTiming   {


    public static void main(String[] args) {
        SortingAlgorithms s = new SortingAlgorithms();
        int[] generatedArr;
        int[] generatedArr2;
        generatedArr = generateArr(200);
        generatedArr2 = generatedArr;
        String[] generatedArr3;
        String[] generatedArr4;
        generatedArr3 = generateStrArr(200);
        generatedArr4 = generatedArr3;
        long start;
        long end;
        long duration;
        long[] timeValues = new long[10];
        int i=0;
        for (i=0; i<10; i++) {

            start = System.nanoTime();
            s.mergeSort(generatedArr);
            end = System.nanoTime();
            duration = (end - start);
            timeValues[i] =  duration;
        }
        System.out.println("average time for merge");

        calculateAverage(timeValues);
        for (i=0; i<10; i++) {
            start = System.nanoTime();
            s.insertionSort(generatedArr2);
            end = System.nanoTime();
            duration = (end - start);
            timeValues[i] =  duration;

        }
        System.out.println("average time for insertion");
        calculateAverage(timeValues);

        for (i=0; i<10; i++) {
            start = System.nanoTime();

            s.insertionSort(generatedArr3, String::compareTo);
            end = System.nanoTime();
            duration = (end - start);
            timeValues[i] =  duration;

        }
        System.out.println("average time for insertion strings");
        calculateAverage(timeValues);

    }

    public static void calculateAverage(long[] time) {
        long total = 0;
        for (int i=0; i<time.length; i++) {
            total = time[i] + total;
        }
        System.out.println(total/time.length);
    }


    public static int[] generateArr(int n) {
        int[] arr = new int[n];
        Random r = new Random();
        for (int i = 0; i<arr.length; i++) {
            arr[i] = r.nextInt(n*2);
        }
        return arr;
    }

    public static String[] generateStrArr(int n) {
        String[] arr = new String[n];
        Random r = new Random();
        for (int i = 0; i<arr.length; i++) {
            arr[i] = generateWord(10);
        }
        return arr;
    }

    public static String generateWord(int n) {
        int lower = 97;
        int upperbound = 122;
        Random r = new Random();
        StringBuffer string = new StringBuffer(n);
        for (int i =0; i<n; i++) {
            int next = lower+(int)r.nextFloat()*upperbound-lower+1; // https://www.geeksforgeeks.org/generate-random-string-of-given-size-in-java/
            string.append((char)next);
        }
        return string.toString();
    }


}