package time;

import java.util.Comparator;

public class SortingAlgorithms {
    private int[] sorted;
    private int[] numbers;


    public int[] insertionSort(int[] in) {
        sorted = in;
        int size = in.length;
        for (int i =1; i<size; i++) {
            int pivot = sorted[i];
            int j = i-1;

            while (j>= 0 && sorted[j]>pivot) {
                sorted[j+1] = sorted[j];
                j = j-1;
            }
            sorted[j+1] = pivot;
        }
        return sorted;
    }

    public int[] mergeSort(int[] in)    // VG Exercise
    {
      if (in.length == 1) { return in;}
      int half = in.length/2;
      int[] l = new int[half];
      int[] r = new int[in.length-l.length];

      System.arraycopy(in, 0, l, 0, l.length);
      System.arraycopy(in, l.length, r,0, r.length);
      mergeSort(l);
      mergeSort(r);
      int[] sorted = in;
      merge(l,r,sorted);
      return sorted;
    }

    private void merge(int[] l, int[] r, int[] sorted) {
        int first = 0;
        int second = 0;
        int merged = 0;
        while (first < l.length && second < r.length) {
            if (l[first] < r[second]) {
                sorted[merged] = l[first];
                first++;
            }
            else {
                sorted[merged] = r[second];
                second++;
            }
            merged++;
        }

        System.arraycopy(l, first, sorted, merged, l.length-first);
        System.arraycopy(r, second, sorted, merged, r.length-second);
    }

    public String[] insertionSort(String[] in, Comparator<String> c) {
       String[] sorted = in;
        int size = in.length;
        for (int i =1; i<size; i++) {
            String pivot = sorted[i];
            int j = i-1;

            while (j>= 0 && c.compare(sorted[j], pivot)>0) {
                sorted[j+1] = sorted[j];
                j = j-1;
            }
            sorted[j+1] = pivot;
        }
        return sorted;
    }

    public String[] mergeSort(String[] in, Comparator<String> c)   // VG Exercise
    {
        return new String[0];
    }
}
