package binheap;

import static org.junit.jupiter.api.Assertions.*;

class BinaryIntHeapTest {

    @org.junit.jupiter.api.Test
    void insert() {

        BinaryIntHeap heap = new BinaryIntHeap();
        heap.insert(5);
        heap.insert(3);
        heap.insert(17);
        heap.insert(10);
        heap.insert(2);
        heap.insert(19);
        heap.insert(6);
        heap.insert(22);
        assertArrayEquals(heap.heap, new int[]{Integer.MAX_VALUE,22,19,17,10,2,5,6,3,0,0,0,0,0,0,0} );
    }

    @org.junit.jupiter.api.Test
    void getParent() {
        BinaryIntHeap heap = new BinaryIntHeap();
        heap.insert(3);
        heap.insert(5);
        heap.insert(7);
        //7 will be parent of 5
        assertEquals(heap.heap[heap.getParent(2)], 7);
        }

    @org.junit.jupiter.api.Test
    void pullHighest() {
        BinaryIntHeap heap = new BinaryIntHeap();
        heap.insert(3);
        heap.insert(5);
        heap.insert(7);
        //7 will be parent of 5
        assertEquals(heap.pullHighest(), 7);
    }

    @org.junit.jupiter.api.Test
    void size() {
        BinaryIntHeap heap = new BinaryIntHeap();
        heap.insert(3);
        heap.insert(5);
        heap.insert(7);
        assertEquals(heap.size(), 3);
    }

    @org.junit.jupiter.api.Test
    void isEmpty() {
        BinaryIntHeap heap = new BinaryIntHeap();
        assertEquals(heap.isEmpty(), true);

    }

    @org.junit.jupiter.api.Test
    void main() {
    }
}