package binheap;

public class BinaryIntHeap  {
    private int max = 15;
    public int[] heap;
    private int size;

    public BinaryIntHeap()   // Constructs an empty heap
    {
        heap = new int[max+1];
        size =0;
        heap[0] = Integer.MAX_VALUE;
    }

    public void insert(int n) // Add n to heap
    {
     heap[++size] = n;
     int curr = size;
     while (heap[curr] > heap[getParent(curr)]) {
         swap(curr, getParent(curr));
             curr = getParent(curr);
         }
     }


    private void swap(int f, int s) {
        int temp = heap[f];
        heap[f] = heap[s];
        heap[s] = temp;
    }

    private void fixHeap(int i) {
        if (i >= (size/2) && i<= size) {
            return;
        }

        if(heap[i] < heap[getLeftChild(i)] || heap[i] < heap[getRightChild(i)]) {
            if(heap[getLeftChild(i)] >heap[getRightChild(i)]) {
                swap(i, getLeftChild(i));
                fixHeap(getLeftChild(i));
            }
            else {
                swap(i, getRightChild(i));
                fixHeap(getRightChild(i));
            }
        }
    }



    public int getLeftChild(int index) {
        return (2 * index);
    }

    public int getRightChild(int index) {
        return (2 * index) +1;
    }

    public int getParent(int index) {
        return index / 2;
    }


    public int pullHighest()    // Return and remove element with highest priority
    {
        int max = heap[1];
        heap[1] = heap[size--];
        fixHeap(1);
        return max;
    }

    public int size()         // Current heap size
    {
        return this.size;
    }

    public boolean isEmpty() // True if heap is empty
    {
        if (this.size == 0) {
            return true;
        }
        else return false;
    }

    public static void main(String[] args) {
        BinaryIntHeap heap = new BinaryIntHeap();
        heap.insert(5);
        heap.insert(3);
        heap.insert(17);
        heap.insert(10);
        heap.insert(2);
        heap.insert(19);
        heap.insert(6);
        heap.insert(22);
        heap.insert(9);
    }

}
