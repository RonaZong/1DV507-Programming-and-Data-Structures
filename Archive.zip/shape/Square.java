package xz222az_assign1.shape;

public class Square extends Rectangle {
    private double side;

    public Square(String name, double side){
        super(name,side,side);
    }


}
